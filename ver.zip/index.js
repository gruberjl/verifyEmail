const emailExistence = require('email-existence')

exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Hello from Lambda');
};

//emailExistence.check('email@domain.com', function(error, response){
//	console.log('res: '+response);
//});
